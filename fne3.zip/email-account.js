// Shared "Email Address" card -- add/verify/change the current account's
// recovery email. Mounted identically into the user dashboard's Profile
// tab, and into the admin/sub-admin dashboards' Overview tab (so admins and
// sub-admins can add their own recovery email too, since forgot-password
// now requires one for every role). Talks to the role-agnostic
// /api/account/email* endpoints -- same widget, same backend, no
// per-role duplication.

function initEmailCard(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  let state = { email: null, emailVerified: false };
  let mode = "view"; // view | edit | otp
  let cooldownTimer = null;
  let cooldownUntil = 0;
  let pendingEmail = null;

  async function load() {
    try {
      state = await api("/account/email");
    } catch {
      state = { email: null, emailVerified: false };
    }
    mode = "view";
    render();
  }

  function startCooldown(seconds) {
    cooldownUntil = Date.now() + seconds * 1000;
    if (cooldownTimer) clearInterval(cooldownTimer);
    cooldownTimer = setInterval(() => {
      if (Date.now() >= cooldownUntil) {
        clearInterval(cooldownTimer);
        cooldownTimer = null;
      }
      render();
    }, 1000);
  }

  function cooldownRemaining() {
    return Math.max(0, Math.ceil((cooldownUntil - Date.now()) / 1000));
  }

  function render() {
    if (mode === "view") {
      container.innerHTML = state.email
        ? `
          <div class="email-card-row">
            <div>
              <span class="email-card-address">${escapeHtml(state.email)}</span>
              ${state.emailVerified ? `<span class="email-badge verified">✓ Verified</span>` : `<span class="email-badge unverified">Not Verified</span>`}
            </div>
            <button type="button" class="inline-btn ghost" id="email-card-action" data-testid="email-card-action">
              ${state.emailVerified ? "Change Email" : "Verify Now"}
            </button>
          </div>
          <p class="form-note" id="email-card-note"></p>
        `
        : `
          <div class="email-card-row">
            <span class="hint">Not added</span>
            <button type="button" class="inline-btn ghost" id="email-card-action" data-testid="email-card-action">Add Email</button>
          </div>
          <p class="form-note" id="email-card-note"></p>
        `;
      document.getElementById("email-card-action").addEventListener("click", () => {
        if (state.email && !state.emailVerified) {
          // Already have a pending unverified email -- go straight to OTP entry.
          mode = "otp";
        } else {
          mode = "edit";
        }
        render();
      });
    } else if (mode === "edit") {
      container.innerHTML = `
        <div class="email-card-form">
          ${state.email ? `<p class="hint" style="margin:0 0 0.5rem;">Current: ${escapeHtml(state.email)}${state.emailVerified ? " (verified)" : ""}</p>` : ""}
          <label for="email-card-input">${state.emailVerified ? "New Email" : "Email Address"}</label>
          <input type="email" id="email-card-input" placeholder="you@example.com" data-testid="email-card-input">
          <div class="email-card-actions">
            <button type="button" class="inline-btn ghost" id="email-card-cancel">Cancel</button>
            <button type="button" class="inline-btn" id="email-card-send" data-testid="email-card-send">Send OTP</button>
          </div>
          <p class="form-note" id="email-card-note"></p>
        </div>
      `;
      document.getElementById("email-card-cancel").addEventListener("click", () => {
        mode = "view";
        render();
      });
      document.getElementById("email-card-send").addEventListener("click", async () => {
        const email = document.getElementById("email-card-input").value.trim();
        const note = document.getElementById("email-card-note");
        note.textContent = "";
        note.className = "form-note";
        if (!email) {
          note.textContent = "Enter an email address.";
          note.className = "form-note error";
          return;
        }
        try {
          const res = await api("/account/email/send-otp", { method: "POST", body: { email } });
          pendingEmail = res.email;
          mode = "otp";
          render();
        } catch (err) {
          note.textContent = err.message;
          note.className = "form-note error";
        }
      });
    } else if (mode === "otp") {
      const remaining = cooldownRemaining();
      container.innerHTML = `
        <div class="email-card-form">
          <p class="hint" style="margin:0 0 0.5rem;">Enter the 6-digit OTP sent to ${escapeHtml(pendingEmail || state.email || "your email")}.</p>
          <label for="email-card-otp">OTP</label>
          <input type="text" id="email-card-otp" inputmode="numeric" maxlength="6" placeholder="123456" data-testid="email-card-otp">
          <div class="email-card-actions">
            <button type="button" class="inline-btn ghost" id="email-card-cancel">Cancel</button>
            <button type="button" class="inline-btn" id="email-card-verify" data-testid="email-card-verify">Verify</button>
          </div>
          <button type="button" class="fp-resend-link" id="email-card-resend" ${remaining > 0 ? "disabled" : ""}>
            ${remaining > 0 ? `Resend OTP (${remaining}s)` : "Resend OTP"}
          </button>
          <p class="form-note" id="email-card-note"></p>
        </div>
      `;
      document.getElementById("email-card-cancel").addEventListener("click", () => {
        mode = "view";
        render();
      });
      document.getElementById("email-card-verify").addEventListener("click", async () => {
        const otp = document.getElementById("email-card-otp").value.trim();
        const note = document.getElementById("email-card-note");
        note.textContent = "";
        note.className = "form-note";
        if (!otp) {
          note.textContent = "Enter the OTP.";
          note.className = "form-note error";
          return;
        }
        try {
          await api("/account/email/verify", { method: "POST", body: { otp } });
          await load();
          const successNote = document.getElementById("email-card-note");
          if (successNote) {
            successNote.textContent = "Email verified.";
            successNote.className = "form-note success";
          }
        } catch (err) {
          note.textContent = err.message;
          note.className = "form-note error";
        }
      });
      document.getElementById("email-card-resend").addEventListener("click", async () => {
        if (cooldownRemaining() > 0) return;
        const note = document.getElementById("email-card-note");
        try {
          await api("/account/email/send-otp", { method: "POST", body: pendingEmail ? { email: pendingEmail } : {} });
          startCooldown(60);
          note.textContent = "A new OTP has been sent.";
          note.className = "form-note success";
        } catch (err) {
          note.textContent = err.message;
          note.className = "form-note error";
        }
      });
      if (remaining === 0) startCooldown(60);
    }
  }

  load();
}
