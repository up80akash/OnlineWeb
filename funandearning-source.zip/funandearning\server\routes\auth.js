const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");
const { JWT_SECRET } = require("../middleware/auth");

const router = express.Router();
const PHONE_REGEX = /^[6-9]\d{9}$/;

router.post("/login", (req, res) => {
  const { phone, password } = req.body || {};

  if (!PHONE_REGEX.test(String(phone || "")) || !password) {
    return res.status(400).json({ error: "Enter a valid 10-digit mobile number and password." });
  }

  const user = db.prepare("SELECT * FROM users WHERE phone = ?").get(phone);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Invalid phone number or password." });
  }
  if (user.status === "locked") {
    return res.status(403).json({ error: "This account has been locked. Contact the admin." });
  }

  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: "12h" });

  res.json({
    token,
    role: user.role,
    name: user.name,
    phone: user.phone,
    walletBalance: user.wallet_balance,
  });
});

router.post("/register", (req, res) => {
  const { name, phone, password } = req.body || {};

  if (!name || String(name).trim().length < 2) {
    return res.status(400).json({ error: "Enter a valid name." });
  }
  if (!PHONE_REGEX.test(String(phone || ""))) {
    return res.status(400).json({ error: "Enter a valid 10-digit mobile number." });
  }
  if (!password || String(password).length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }

  const existing = db.prepare("SELECT id FROM users WHERE phone = ?").get(phone);
  if (existing) {
    return res.status(409).json({ error: "A user with this mobile number already exists." });
  }

  const subadmin = db.findSubadminForNewUser();
  if (!subadmin) {
    return res.status(503).json({ error: "Registration is temporarily unavailable. Please try again later." });
  }

  const hash = bcrypt.hashSync(password, 10);
  const result = db
    .prepare(
      "INSERT INTO users (role, name, phone, password_hash, status, wallet_balance, sub_admin_id) VALUES ('user', ?, ?, ?, 'active', 0, ?)"
    )
    .run(String(name).trim(), phone, hash, subadmin.id);

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(result.lastInsertRowid);
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: "12h" });

  res.status(201).json({
    token,
    role: user.role,
    name: user.name,
    phone: user.phone,
    walletBalance: user.wallet_balance,
  });
});

module.exports = router;
