const express = require("express");
const db = require("../db");
const { authenticate, requireRole } = require("../middleware/auth");

const router = express.Router();

router.use(authenticate, requireRole("user"));

router.get("/me", (req, res) => {
  const subadmin = req.user.sub_admin_id
    ? db.prepare("SELECT name, phone FROM users WHERE id = ?").get(req.user.sub_admin_id)
    : null;

  res.json({
    name: req.user.name,
    phone: req.user.phone,
    status: req.user.status,
    walletBalance: req.user.wallet_balance,
    createdAt: req.user.created_at,
    subAdmin: subadmin,
  });
});

router.get("/payment-methods", (req, res) => {
  const rows = db
    .prepare(
      "SELECT id, method, details FROM payment_requests WHERE subadmin_id = ? AND status = 'approved' ORDER BY created_at DESC"
    )
    .all(req.user.sub_admin_id);
  res.json(rows);
});

// ---- Deposits ----
router.get("/deposits", (req, res) => {
  const rows = db
    .prepare("SELECT * FROM user_deposits WHERE user_id = ? ORDER BY created_at DESC")
    .all(req.user.id);
  res.json(
    rows.map((r) => ({
      id: r.id,
      amount: r.amount,
      note: r.note,
      status: r.status,
      createdAt: r.created_at,
      reviewedAt: r.reviewed_at,
    }))
  );
});

router.post("/deposits", (req, res) => {
  const amount = Number(req.body?.amount);
  const note = req.body?.note ? String(req.body.note).slice(0, 300) : null;

  if (!Number.isInteger(amount) || amount <= 0) {
    return res.status(400).json({ error: "Enter a positive whole number of tokens." });
  }

  const result = db
    .prepare("INSERT INTO user_deposits (user_id, amount, note) VALUES (?, ?, ?)")
    .run(req.user.id, amount, note);

  res.status(201).json({ id: result.lastInsertRowid, amount, note, status: "pending" });
});

// ---- Withdrawals ----
router.get("/withdrawals", (req, res) => {
  const rows = db
    .prepare("SELECT * FROM user_withdrawals WHERE user_id = ? ORDER BY created_at DESC")
    .all(req.user.id);
  res.json(
    rows.map((r) => ({
      id: r.id,
      amount: r.amount,
      payoutDetails: r.payout_details,
      status: r.status,
      createdAt: r.created_at,
      reviewedAt: r.reviewed_at,
    }))
  );
});

router.post("/withdrawals", (req, res) => {
  const amount = Number(req.body?.amount);
  const payoutDetails = req.body?.payoutDetails ? String(req.body.payoutDetails).trim().slice(0, 300) : "";

  if (!Number.isInteger(amount) || amount <= 0) {
    return res.status(400).json({ error: "Enter a positive whole number of tokens." });
  }
  if (!payoutDetails) {
    return res.status(400).json({ error: "Provide where the withdrawal should be sent." });
  }
  if (amount > req.user.wallet_balance) {
    return res.status(400).json({ error: "Insufficient wallet balance." });
  }

  let requestId;
  const submit = db.transaction(() => {
    db.prepare("UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?").run(amount, req.user.id);
    const result = db
      .prepare("INSERT INTO user_withdrawals (user_id, amount, payout_details) VALUES (?, ?, ?)")
      .run(req.user.id, amount, payoutDetails);
    requestId = result.lastInsertRowid;
  });
  submit();

  res.status(201).json({ id: requestId, amount, payoutDetails, status: "pending" });
});

// ---- Support ----
router.get("/support", (req, res) => {
  const rows = db
    .prepare("SELECT * FROM support_messages WHERE user_id = ? ORDER BY created_at ASC")
    .all(req.user.id);
  res.json(
    rows.map((r) => ({
      id: r.id,
      senderRole: r.sender_role,
      message: r.message,
      createdAt: r.created_at,
    }))
  );
});

router.post("/support", (req, res) => {
  const message = req.body?.message ? String(req.body.message).trim().slice(0, 1000) : "";
  if (!message) {
    return res.status(400).json({ error: "Enter a message." });
  }
  if (!req.user.sub_admin_id) {
    return res.status(400).json({ error: "No support agent is assigned to your account yet." });
  }

  const result = db
    .prepare("INSERT INTO support_messages (user_id, sender_role, message) VALUES (?, 'user', ?)")
    .run(req.user.id, message);

  res.status(201).json({ id: result.lastInsertRowid, senderRole: "user", message, status: "sent" });
});

module.exports = router;
