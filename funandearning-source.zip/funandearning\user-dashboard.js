requireRole("user");

function setNote(id, message, type) {
  const el = document.getElementById(id);
  el.textContent = message || "";
  el.className = "form-note" + (type ? ` ${type}` : "");
}

function setBalance(amount) {
  document.getElementById("wallet-pill").textContent = `${amount} tokens`;
  document.getElementById("wallet-balance").textContent = amount;
}

async function loadMe() {
  const me = await api("/user/me");
  setBalance(me.walletBalance);
  document.getElementById("profile-name").textContent = me.name;
  document.getElementById("profile-phone").textContent = `+91 ${me.phone}`;
  document.getElementById("profile-status").textContent = me.status;
  document.getElementById("profile-created").textContent = formatDate(me.createdAt);
  document.getElementById("profile-subadmin").textContent = me.subAdmin
    ? `${me.subAdmin.name} (+91 ${me.subAdmin.phone})`
    : "Not assigned yet";
}

async function loadPaymentMethods() {
  const rows = await api("/user/payment-methods");
  const list = document.getElementById("payment-methods-list");
  if (rows.length === 0) {
    list.innerHTML = `<p class="hint">No payment methods have been added by your support agent yet.</p>`;
    return;
  }
  list.innerHTML = rows
    .map(
      (r) => `
    <div style="padding: 0.75rem 0; border-bottom: 1px solid rgba(255,255,255,0.08);">
      <strong>${escapeHtml(r.method)}</strong>
      <div class="hint">${escapeHtml(r.details)}</div>
    </div>`
    )
    .join("");
}

async function loadDeposits() {
  const rows = await api("/user/deposits");
  const body = document.getElementById("deposits-body");
  if (rows.length === 0) {
    body.innerHTML = `<tr class="empty-row"><td colspan="4">No deposit requests yet.</td></tr>`;
    return;
  }
  body.innerHTML = rows
    .map(
      (r) => `
    <tr>
      <td>${r.amount}</td>
      <td>${escapeHtml(r.note || "—")}</td>
      <td><span class="badge ${r.status}">${r.status}</span></td>
      <td>${formatDate(r.createdAt)}</td>
    </tr>`
    )
    .join("");
}

async function loadWithdrawals() {
  const rows = await api("/user/withdrawals");
  const body = document.getElementById("withdrawals-body");
  if (rows.length === 0) {
    body.innerHTML = `<tr class="empty-row"><td colspan="4">No withdrawal requests yet.</td></tr>`;
    return;
  }
  body.innerHTML = rows
    .map(
      (r) => `
    <tr>
      <td>${r.amount}</td>
      <td>${escapeHtml(r.payoutDetails)}</td>
      <td><span class="badge ${r.status}">${r.status}</span></td>
      <td>${formatDate(r.createdAt)}</td>
    </tr>`
    )
    .join("");
}

async function loadSupport() {
  const rows = await api("/user/support");
  const box = document.getElementById("chat-messages");
  if (rows.length === 0) {
    box.innerHTML = `<p class="chat-empty">No messages yet. Say hello to your support agent below.</p>`;
    return;
  }
  box.innerHTML = rows
    .map(
      (m) => `
    <div class="chat-bubble ${m.senderRole === "user" ? "mine" : "theirs"}">
      ${escapeHtml(m.message)}
      <span class="meta">${m.senderRole === "user" ? "You" : "Support"} · ${formatDate(m.createdAt)}</span>
    </div>`
    )
    .join("");
  box.scrollTop = box.scrollHeight;
}

document.getElementById("deposit-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const amount = Number(document.getElementById("deposit-amount").value);
  const note = document.getElementById("deposit-note").value.trim();
  setNote("deposit-note-msg", "", "");
  try {
    await api("/user/deposits", { method: "POST", body: { amount, note } });
    document.getElementById("deposit-form").reset();
    setNote("deposit-note-msg", "Deposit request submitted.", "success");
    loadDeposits();
  } catch (err) {
    setNote("deposit-note-msg", err.message, "error");
  }
});

document.getElementById("withdraw-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const amount = Number(document.getElementById("withdraw-amount").value);
  const payoutDetails = document.getElementById("withdraw-details").value.trim();
  setNote("withdraw-note-msg", "", "");
  try {
    await api("/user/withdrawals", { method: "POST", body: { amount, payoutDetails } });
    document.getElementById("withdraw-form").reset();
    setNote("withdraw-note-msg", "Withdrawal request submitted.", "success");
    await Promise.all([loadWithdrawals(), loadMe()]);
  } catch (err) {
    setNote("withdraw-note-msg", err.message, "error");
  }
});

document.getElementById("chat-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = document.getElementById("chat-input");
  const message = input.value.trim();
  if (!message) return;
  try {
    await api("/user/support", { method: "POST", body: { message } });
    input.value = "";
    loadSupport();
  } catch (err) {
    alert(err.message);
  }
});

loadMe();
loadPaymentMethods();
loadDeposits();
loadWithdrawals();
loadSupport();
