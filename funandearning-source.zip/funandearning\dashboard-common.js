function getToken() {
  return localStorage.getItem("fe_token");
}

function requireRole(role) {
  const token = getToken();
  const storedRole = localStorage.getItem("fe_role");
  if (!token || storedRole !== role) {
    window.location.href = "admin-login.html";
    throw new Error("Not authenticated");
  }
}

function logout() {
  localStorage.removeItem("fe_token");
  localStorage.removeItem("fe_role");
  localStorage.removeItem("fe_name");
  window.location.href = "admin-login.html";
}

async function api(path, options = {}) {
  const res = await fetch(`/api${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${getToken()}`,
      ...(options.headers || {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  if (res.status === 401) {
    logout();
    throw new Error("Session expired");
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || "Something went wrong.");
  }
  return data;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

function formatDate(iso) {
  if (!iso) return "—";
  return new Date(iso.replace(" ", "T") + "Z").toLocaleString(undefined, {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

function initTabs() {
  const tabs = document.querySelectorAll(".dash-tab");
  const panels = document.querySelectorAll(".dash-panel");
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      panels.forEach((p) => p.classList.remove("active"));
      tab.classList.add("active");
      document.getElementById(tab.dataset.target).classList.add("active");
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const nameEl = document.getElementById("dash-user-name");
  if (nameEl) nameEl.textContent = localStorage.getItem("fe_name") || "";

  const logoutBtn = document.getElementById("dash-logout-btn");
  if (logoutBtn) logoutBtn.addEventListener("click", logout);

  initTabs();
});
