// Forgot Password / OTP reset flow -- shared by login.html (users) and
// admin-login.html (admin + sub-admin, who authenticate the same way by
// phone). One implementation, reused from both pages instead of a
// duplicated per-role reset system, matching the app's single phone+password
// auth model end to end.
//
// Expects the modal markup from the `forgotPasswordModalHtml()` template
// below to be present on the page (both login pages include it) and a
// trigger element with id="forgot-password-link".

(function () {
  const INDIAN_MOBILE_REGEX = /^[6-9]\d{9}$/;
  let resetPhone = "";
  let resetToken = "";

  function el(id) {
    return document.getElementById(id);
  }

  function showStep(step) {
    ["fp-step-phone", "fp-step-otp", "fp-step-reset", "fp-step-done"].forEach((id) => {
      el(id).classList.toggle("hidden", id !== `fp-step-${step}`);
    });
  }

  function setMsg(id, message, isError) {
    const node = el(id);
    node.textContent = message || "";
    node.style.color = isError ? "#ff8383" : "";
  }

  function openModal() {
    resetPhone = "";
    resetToken = "";
    el("fp-phone-input").value = "";
    el("fp-otp-input").value = "";
    el("fp-new-password").value = "";
    el("fp-confirm-password").value = "";
    setMsg("fp-phone-msg", "", false);
    setMsg("fp-otp-msg", "", false);
    setMsg("fp-reset-msg", "", false);
    showStep("phone");
    el("forgot-password-modal").classList.remove("hidden");
  }

  function closeModal() {
    el("forgot-password-modal").classList.add("hidden");
  }

  async function postJson(path, body) {
    const res = await fetch(`/api${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Something went wrong.");
    return data;
  }

  async function sendOtp() {
    const phone = el("fp-phone-input").value.trim();
    setMsg("fp-phone-msg", "", false);
    if (!INDIAN_MOBILE_REGEX.test(phone)) {
      setMsg("fp-phone-msg", "Enter a valid 10-digit mobile number.", true);
      return;
    }
    const btn = el("fp-send-otp-btn");
    btn.disabled = true;
    try {
      await postJson("/auth/forgot-password", { phone });
      resetPhone = phone;
      el("fp-otp-phone-label").textContent = `+91 ${phone}`;
      showStep("otp");
    } catch (err) {
      setMsg("fp-phone-msg", err.message, true);
    } finally {
      btn.disabled = false;
    }
  }

  async function verifyOtp() {
    const otp = el("fp-otp-input").value.trim();
    setMsg("fp-otp-msg", "", false);
    if (!otp) {
      setMsg("fp-otp-msg", "Enter the OTP you received.", true);
      return;
    }
    const btn = el("fp-verify-otp-btn");
    btn.disabled = true;
    try {
      const data = await postJson("/auth/verify-reset-otp", { phone: resetPhone, otp });
      resetToken = data.resetToken;
      showStep("reset");
    } catch (err) {
      setMsg("fp-otp-msg", err.message, true);
    } finally {
      btn.disabled = false;
    }
  }

  async function resendOtp() {
    setMsg("fp-otp-msg", "", false);
    try {
      await postJson("/auth/forgot-password", { phone: resetPhone });
      setMsg("fp-otp-msg", "A new OTP has been sent.", false);
    } catch (err) {
      setMsg("fp-otp-msg", err.message, true);
    }
  }

  async function submitNewPassword() {
    const newPassword = el("fp-new-password").value;
    const confirmPassword = el("fp-confirm-password").value;
    setMsg("fp-reset-msg", "", false);

    if (newPassword.length < 6) {
      setMsg("fp-reset-msg", "Password must be at least 6 characters.", true);
      return;
    }
    if (newPassword !== confirmPassword) {
      setMsg("fp-reset-msg", "Passwords do not match.", true);
      return;
    }

    const btn = el("fp-reset-btn");
    btn.disabled = true;
    try {
      await postJson("/auth/reset-password", { resetToken, newPassword, confirmPassword });
      showStep("done");
    } catch (err) {
      setMsg("fp-reset-msg", err.message, true);
    } finally {
      btn.disabled = false;
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    const trigger = el("forgot-password-link");
    if (!trigger || !el("forgot-password-modal")) return;

    trigger.addEventListener("click", (e) => {
      e.preventDefault();
      openModal();
    });
    el("fp-modal-close").addEventListener("click", closeModal);
    el("forgot-password-modal").addEventListener("click", (e) => {
      if (e.target.id === "forgot-password-modal") closeModal();
    });
    el("fp-send-otp-btn").addEventListener("click", sendOtp);
    el("fp-verify-otp-btn").addEventListener("click", verifyOtp);
    el("fp-resend-otp-btn").addEventListener("click", resendOtp);
    el("fp-reset-btn").addEventListener("click", submitNewPassword);
    el("fp-done-close-btn").addEventListener("click", closeModal);
  });
})();
