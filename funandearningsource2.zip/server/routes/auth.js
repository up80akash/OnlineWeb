const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const db = require("../db");
const { JWT_SECRET } = require("../middleware/auth");
const otpLib = require("../lib/otp");

const router = express.Router();
const PHONE_REGEX = /^[6-9]\d{9}$/;
const RESET_TOKEN_TTL = `${otpLib.OTP_TTL_MINUTES}m`;

router.post("/login", (req, res) => {
  const { phone, password } = req.body || {};

  if (!PHONE_REGEX.test(String(phone || "")) || !password) {
    return res.status(400).json({ error: "Enter a valid 10-digit mobile number and password." });
  }

  const user = db.prepare("SELECT * FROM users WHERE phone = ?").get(phone);
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: "Invalid phone number or password." });
  }
  if (user.status === "locked") {
    return res.status(403).json({ error: "This account has been locked. Contact the admin." });
  }

  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: "12h" });

  res.json({
    token,
    role: user.role,
    name: user.name,
    phone: user.phone,
    walletBalance: user.wallet_balance,
  });
});

router.post("/register", (req, res) => {
  const { name, phone, password } = req.body || {};

  if (!name || String(name).trim().length < 2) {
    return res.status(400).json({ error: "Enter a valid name." });
  }
  if (!PHONE_REGEX.test(String(phone || ""))) {
    return res.status(400).json({ error: "Enter a valid 10-digit mobile number." });
  }
  if (!password || String(password).length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }

  const existing = db.prepare("SELECT id FROM users WHERE phone = ?").get(phone);
  if (existing) {
    return res.status(409).json({ error: "A user with this mobile number already exists." });
  }

  const subadmin = db.findSubadminForNewUser();
  if (!subadmin) {
    return res.status(503).json({ error: "Registration is temporarily unavailable. Please try again later." });
  }

  const hash = bcrypt.hashSync(password, 10);
  const result = db
    .prepare(
      "INSERT INTO users (role, name, phone, password_hash, status, wallet_balance, sub_admin_id) VALUES ('user', ?, ?, ?, 'active', 0, ?)"
    )
    .run(String(name).trim(), phone, hash, subadmin.id);

  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(result.lastInsertRowid);
  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: "12h" });

  res.status(201).json({
    token,
    role: user.role,
    name: user.name,
    phone: user.phone,
    walletBalance: user.wallet_balance,
  });
});

// ---- Forgot password (OTP) ----
// Works for any role (user, subadmin, admin) since they all authenticate by
// phone against the same users table -- one flow, reused from both
// login.html and admin-login.html, rather than a separate reset system per
// role.
const GENERIC_OTP_SENT = { ok: true, message: "If this mobile number is registered, an OTP has been sent to it." };

router.post("/forgot-password", (req, res) => {
  const phone = String(req.body?.phone || "");
  if (!PHONE_REGEX.test(phone)) {
    return res.status(400).json({ error: "Enter a valid 10-digit mobile number." });
  }

  const user = db.prepare("SELECT id FROM users WHERE phone = ?").get(phone);
  if (!user) {
    // Same response whether or not the number is registered -- avoids
    // leaking which phone numbers have accounts.
    return res.json(GENERIC_OTP_SENT);
  }

  const windowStart = db.prepare(`SELECT datetime('now', '-${otpLib.REQUEST_WINDOW_MINUTES} minutes') AS t`).get().t;
  const recent = db
    .prepare("SELECT COUNT(*) AS n FROM password_resets WHERE user_id = ? AND created_at >= ?")
    .get(user.id, windowStart);
  if (recent.n >= otpLib.MAX_REQUESTS_PER_WINDOW) {
    return res.status(429).json({ error: "Too many OTP requests. Please wait a while before trying again." });
  }

  const otp = otpLib.generateOtp();
  const otpHash = otpLib.hashOtp(otp);
  const expiresAt = db.prepare(`SELECT datetime('now', '+${otpLib.OTP_TTL_MINUTES} minutes') AS t`).get().t;

  const issue = db.transaction(() => {
    // A fresh OTP immediately invalidates any earlier unconsumed one for
    // this user -- only the newest can ever verify.
    db.prepare("UPDATE password_resets SET consumed_at = datetime('now') WHERE user_id = ? AND consumed_at IS NULL").run(user.id);
    db.prepare("INSERT INTO password_resets (user_id, otp_hash, expires_at) VALUES (?, ?, ?)").run(user.id, otpHash, expiresAt);
  });
  issue();

  otpLib.sendOtpSms(phone, otp); // never included in the HTTP response
  res.json(GENERIC_OTP_SENT);
});

router.post("/verify-reset-otp", (req, res) => {
  const phone = String(req.body?.phone || "");
  const otp = String(req.body?.otp || "").trim();
  if (!PHONE_REGEX.test(phone) || !otp) {
    return res.status(400).json({ error: "Enter the mobile number and the OTP you received." });
  }

  const user = db.prepare("SELECT id FROM users WHERE phone = ?").get(phone);
  const genericError = { error: "Invalid or expired OTP. Request a new one." };
  if (!user) {
    return res.status(400).json(genericError);
  }

  // verified = 0 makes this OTP genuinely single-use: once it's produced a
  // reset token (below), the same code can never verify again, even before
  // that token goes on to consume the row via reset-password.
  const row = db
    .prepare(
      "SELECT * FROM password_resets WHERE user_id = ? AND consumed_at IS NULL AND verified = 0 AND expires_at > datetime('now') ORDER BY id DESC LIMIT 1"
    )
    .get(user.id);
  if (!row) {
    return res.status(400).json(genericError);
  }
  if (row.attempts >= otpLib.MAX_VERIFY_ATTEMPTS) {
    return res.status(429).json({ error: "Too many incorrect attempts. Request a new OTP." });
  }
  if (!otpLib.verifyOtp(otp, row.otp_hash)) {
    db.prepare("UPDATE password_resets SET attempts = attempts + 1 WHERE id = ?").run(row.id);
    const attemptsLeft = otpLib.MAX_VERIFY_ATTEMPTS - (row.attempts + 1);
    return res.status(400).json({ error: attemptsLeft > 0 ? `Invalid OTP. ${attemptsLeft} attempt${attemptsLeft === 1 ? "" : "s"} left.` : "Invalid OTP. Request a new one." });
  }

  db.prepare("UPDATE password_resets SET verified = 1 WHERE id = ?").run(row.id);

  // Short-lived, single-purpose token binding the next step to this exact
  // verified OTP row -- the client can't skip straight to reset-password
  // without having actually verified an OTP first.
  const resetToken = jwt.sign({ purpose: "password_reset", userId: user.id, resetId: row.id }, JWT_SECRET, {
    expiresIn: RESET_TOKEN_TTL,
  });
  res.json({ ok: true, resetToken });
});

router.post("/reset-password", (req, res) => {
  const { resetToken, newPassword, confirmPassword } = req.body || {};

  if (!newPassword || String(newPassword).length < 6) {
    return res.status(400).json({ error: "Password must be at least 6 characters." });
  }
  if (newPassword !== confirmPassword) {
    return res.status(400).json({ error: "Passwords do not match." });
  }

  const invalidSession = { error: "This reset session has expired. Please verify the OTP again." };
  let payload;
  try {
    payload = jwt.verify(resetToken, JWT_SECRET);
  } catch {
    return res.status(400).json(invalidSession);
  }
  if (payload.purpose !== "password_reset") {
    return res.status(400).json(invalidSession);
  }

  const row = db.prepare("SELECT * FROM password_resets WHERE id = ? AND user_id = ?").get(payload.resetId, payload.userId);
  if (!row || !row.verified || row.consumed_at) {
    return res.status(400).json({ error: "This reset session is no longer valid. Please start again." });
  }

  const hash = bcrypt.hashSync(newPassword, 10);
  const run = db.transaction(() => {
    db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(hash, payload.userId);
    // Consuming it here (in addition to the OTP-issuance invalidation above)
    // means this exact reset session can never be replayed even if the
    // token leaked after use.
    db.prepare("UPDATE password_resets SET consumed_at = datetime('now') WHERE id = ?").run(row.id);
  });
  run();

  res.json({ ok: true, message: "Password reset successful. You can now log in with your new password." });
});

module.exports = router;
